# franka_panda_control
A set of ROS2 packages designed to control the FRANKA PANDA robot.
