from launch import LaunchDescription
from launch_ros.actions import Node


def generate_launch_description():
    return LaunchDescription([
        Node(
            package='panda_control',
            namespace='panda',
            executable='panda_cmd_gui',
            # name='panda_cmd_gui_node'
        ),
        Node(
            package='panda_control',
            namespace='panda',
            executable='panda_control',
            # name='panda_control_node'
        ),
    ])