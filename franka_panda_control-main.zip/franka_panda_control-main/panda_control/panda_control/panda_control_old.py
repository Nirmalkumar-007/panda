import rclpy
from rclpy.node import Node
from rclpy import executors

from panda_interfaces.msg import PandaCommand
from panda_interfaces.msg import PandaPose
from scipy.spatial.transform import Rotation as R

import panda_py
from panda_py import constants
from panda_py import controllers
import numpy as np
import time


class PandaCmdSub(Node):

    def __init__(self, desk: panda_py.Desk, panda: panda_py.Panda):
        super().__init__('panda_cmd_subscriber')
        self.desk:panda_py.Desk = desk
        self.panda:panda_py.Panda = panda
        self.panda_pose_pub = PandaPosePub()
        self.subscription = self.create_subscription(
            PandaCommand,
            'panda_command_topic',
            self.callback,
            10)
        self.subscription  # prevent unused variable warning
        # panda.move_to_start()
        print("Starting pose:\n", panda.get_pose())
        self.pub_actual_pose()

    def pub_actual_pose(self):
        actual_orientation = R.from_quat(self.panda.get_orientation()).as_euler('xyz', degrees=True)
        
        self.panda_pose_pub.msg.position.data[0] = self.panda.get_position()[0]
        self.panda_pose_pub.msg.position.data[1] = self.panda.get_position()[1]
        self.panda_pose_pub.msg.position.data[2] = self.panda.get_position()[2]
        self.panda_pose_pub.msg.rotation.data[0] = actual_orientation[0]
        self.panda_pose_pub.msg.rotation.data[1] = actual_orientation[1]
        self.panda_pose_pub.msg.rotation.data[2] = actual_orientation[2]
        self.panda_pose_pub.publish_wrapper()
        return
    
    def callback(self, msg:PandaCommand):
        if msg.run == False:
            rclpy.shutdown()
            return
        elif msg.unlocked == False:
            self.desk.deactivate_fci()
            self.desk.lock()
            return
        else:
            self.desk.unlock()
            self.desk.activate_fci()
        
        if msg.motion_type == 0:
            self.panda.move_to_start()
            print("Destination pose:\n", self.panda.get_pose())
            self.pub_actual_pose()
            return
        
        cmd_rotation = R.from_euler('xyz', [msg.rotation.data[0], msg.rotation.data[1], msg.rotation.data[2]], degrees=True)
        cmd_position = np.zeros((3))
        cmd_position[0] = msg.position.data[0]
        cmd_position[1] = msg.position.data[1]
        cmd_position[2] = msg.position.data[2]

        position = self.panda.get_position()
        orientation = self.panda.get_orientation()
        tmp_orientation = R.from_quat(self.panda.get_orientation())

        if msg.absolute_pose == True:
            position = cmd_position
            orientation = cmd_rotation.as_quat()
        else:
            new_orientation = cmd_rotation * tmp_orientation
            orientation = new_orientation.as_quat()
            position += cmd_position

        pose = np.eye(4)
        pose[0:3, 0:3] = R.from_quat(orientation).as_matrix()
        pose[0:3, 3] = position
        print("Moving to pose:\n", pose)

        if msg.motion_type == 1:
            ctrl = controllers.CartesianImpedance()
            ctrl.set_damping_ratio(1.5)  # Critical damping
            self.panda.start_controller(ctrl)
            self.panda.move_to_pose(pose)
            # ctrl.set_control(position, orientation)
        elif msg.motion_type == 2:
            q = panda_py.ik(pose)
            print("IK solution:\n", q)
            ctrl = controllers.JointPosition()
            self.panda.start_controller(ctrl)
            self.panda.move_to_joint_position(q)
            # ctrl.set_control(q, 0.001*np.ones((7, 1)))

        time.sleep(.5)
        actual_pose = self.panda.get_pose()
        print("Destination pose:\n", actual_pose)

        self.pub_actual_pose()
        return

class PandaPosePub(Node):

    def __init__(self):
        super().__init__('panda_pose_publisher')
        self.msg:PandaPose = PandaPose()
        self.msg.rotation.data.append(0)
        self.msg.rotation.data.append(0)
        self.msg.rotation.data.append(0)
        self.msg.position.data.append(0.0)
        self.msg.position.data.append(0.0)
        self.msg.position.data.append(0.0)
        self.publisher_ = self.create_publisher(PandaPose, 'panda_pose_topic', 10)

    def publish_wrapper(self):
        self.publisher_.publish(self.msg)

def main(args=None):
    rclpy.init(args=args)
    
    desk = panda_py.Desk("192.168.1.11" , "BRL" , "IITADVRBRL")
    # desk.unlock()
    # desk.activate_fci()
    panda = panda_py.Panda("192.168.1.11")

    panda_cmd_sub = PandaCmdSub(desk,panda)

    # executor = executors.SingleThreadedExecutor()
    # executor.add_node(panda_cmd_sub)
    # executor.add_node(panda_pose_pub)
    # executor.spin()

    rclpy.spin(panda_cmd_sub)

    panda_cmd_sub.destroy_node()

    # panda.move_to_start()
    desk.deactivate_fci()
    desk.lock()


if __name__ == '__main__':
    main()
