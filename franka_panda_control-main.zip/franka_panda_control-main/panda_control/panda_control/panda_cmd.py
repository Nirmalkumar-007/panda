import rclpy
from rclpy.node import Node

from panda_interfaces.msg import PandaCommand

class PandaCmdPub(Node):

    def __init__(self):
        super().__init__('panda_cmd_publisher')
        self.publisher_ = self.create_publisher(PandaCommand, 'panda_command_topic', 10)


def main(args=None):
    rclpy.init(args=args)

    panda_cmd_pub = PandaCmdPub()

    msg = PandaCommand()
    msg.run = True
    msg.unlocked = False
    msg.motion_type = 0
    msg.absolute_goal = True
    msg.rotation.data.append(0)
    msg.rotation.data.append(0)
    msg.rotation.data.append(0)
    msg.position.data.append(0.0)
    msg.position.data.append(0.0)
    msg.position.data.append(0.0)

    while msg.run == True:
        msg.run = bool(int(input("Run (1/0): ")))
        if msg.run == True:
            msg.unlocked = bool(int(input("Unlock (1/0): ")))
            if msg.unlocked == True:
                msg.motion_type = int(input("Motion Type (0=start, 1=cartesian, 2=joint): "))
                if msg.motion_type != 0:
                    msg.absolute_goal = bool(int(input("Absolute Goal (1/0): ")))
                    msg.rotation.data[0] = float(input("Rotation [x] in degrees: "))
                    msg.rotation.data[1] = float(input("Rotation [y] in degrees: "))
                    msg.rotation.data[2] = float(input("Rotation [z] in degrees: "))
                    msg.position.data[0] = float(input("Position [x] in meters: "))
                    msg.position.data[1] = float(input("Position [y] in meters: "))
                    msg.position.data[2] = float(input("Position [z] in meters: "))
        
        panda_cmd_pub.publisher_.publish(msg)
        # panda_cmd_pub.get_logger().info('Publishing: "%s"' % str(msg))
        print("--------------------------------")

    panda_cmd_pub.destroy_node()
    rclpy.shutdown()


if __name__ == '__main__':
    main()