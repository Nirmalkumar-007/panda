import rclpy
from rclpy.node import Node

from std_msgs.msg import String
from std_msgs.msg import Float64MultiArray

import panda_py
import time


class CartPoseSub(Node):

    def __init__(self, panda:panda_py.Panda):
        super().__init__('cart_pose_subscriber')
        self.panda:panda_py.Panda = panda
        self.subscription = self.create_subscription(
            Float64MultiArray,
            'cart_pose_topic',
            self.callback,
            10)
        self.subscription  # prevent unused variable warning

    def callback(self, msg:Float64MultiArray):
        if len(msg.data) == 0:
            rclpy.shutdown()
            return
        # self.get_logger().info('I heard: "%f, %f, %f"', msg.data[0], msg.data[1], msg.data[2])
        pose = self.panda.get_pose()
        pose[0, 3] += msg.data[0]
        pose[1, 3] += msg.data[1]
        pose[2 ,3] += msg.data[2]
        self.panda.move_to_pose(pose)


def main(args=None):
    rclpy.init(args=args)
    
    desk = panda_py.Desk("192.168.1.11" , "BRL" , "IITADVRBRL")
    desk.unlock()
    desk.activate_fci()
    panda = panda_py.Panda("192.168.1.11")
    panda.move_to_start()

    cart_pose_sub = CartPoseSub(panda)

    # executor = rclpy.executors.SingleThreadedExecutor()
    # executor.add_node(cart_pose_sub)
    # executor.spin()

    rclpy.spin(cart_pose_sub)
    # Destroy the node explicitly
    # (optional - otherwise it will be done automatically
    # when the garbage collector destroys the node object)
    cart_pose_sub.destroy_node()
    # rclpy.shutdown()

    panda.move_to_start()
    desk.deactivate_fci()
    desk.lock()


if __name__ == '__main__':
    main()
