import rclpy
from rclpy.node import Node
from rclpy import executors

from panda_interfaces.msg import PandaCommand
from panda_interfaces.msg import PandaPose
from panda_interfaces.msg import PandaStatus
from geometry_msgs.msg import Pose
from scipy.spatial.transform import Rotation as R

import panda_py
from panda_py import constants
from panda_py import controllers
import numpy as np
import time


class PandaCmdSub(Node):

    def __init__(self, desk: panda_py.Desk, panda: panda_py.Panda):
        super().__init__('panda_status_subscriber')
        self.absolute_pose = True
        self.motion_type = 1
        self.desk:panda_py.Desk = desk
        self.panda:panda_py.Panda = panda
        self.panda_pose_pub = PandaPosePub()
        self.status_subscription = self.create_subscription(
            PandaStatus,
            'panda_status_topic',
            self.status_callback,
            10)
        self.cmd_subscription = self.create_subscription(
            Pose,
            'panda_cmd_topic',
            self.cmd_callback,
            10)
        self.status_subscription  # prevent unused variable warning
        self.cmd_subscription  # prevent unused variable warning
        # panda.move_to_start()
        print("Starting pose:\n", panda.get_pose())
        self.pub_actual_pose()
    
    def status_callback(self, msg:PandaStatus):
        if msg.run == False:
            rclpy.shutdown()
            return
        elif msg.unlocked == False:
            self.desk.deactivate_fci()
            self.desk.lock()
            return
        else:
            self.desk.unlock()
            self.desk.activate_fci()

        self.absolute_pose = msg.absolute_pose
        self.motion_type = msg.motion_type
        if self.motion_type == 0:
            self.panda.move_to_start()
            print("Destination pose:\n", self.panda.get_pose())
            self.pub_actual_pose()
            return

    def cmd_callback(self, msg:Pose):
        cmd_rotation = R.from_quat([msg.orientation.x, msg.orientation.y, msg.orientation.z, msg.orientation.w])
        cmd_position = np.zeros((3))
        cmd_position[0] = msg.position.x
        cmd_position[1] = msg.position.y
        cmd_position[2] = msg.position.z

        position = self.panda.get_position()
        orientation = self.panda.get_orientation()
        tmp_orientation = R.from_quat(self.panda.get_orientation())

        if self.absolute_pose == True:
            position = cmd_position
            orientation = (cmd_rotation.inv() * tmp_orientation)*tmp_orientation
            print("Moving to absolute pose")
        else:
            # orientation = tmp_orientation * cmd_rotation.inv()
            orientation = cmd_rotation * tmp_orientation
            position += cmd_position
            print("Moving to relative pose")

        pose = np.eye(4)
        pose[0:3, 0:3] = orientation.as_matrix()
        pose[0:3, 3] = position
        print("Moving to pose:\n", pose)

        if self.motion_type == 1:
            ctrl = controllers.CartesianImpedance()
            # ctrl.set_damping_ratio(1.5)  # Critical damping
            self.panda.start_controller(ctrl)
            # self.panda.move_to_pose(pose)
            ctrl.set_control(position, orientation.as_quat())
        elif self.motion_type == 2:
            q = panda_py.ik(pose)
            print("IK solution:\n", q)
            ctrl = controllers.JointPosition()
            self.panda.start_controller(ctrl)
            self.panda.move_to_joint_position(q)
            # ctrl.set_control(q, 0.001*np.ones((7, 1)))

        time.sleep(.5)
        actual_pose = self.panda.get_pose()
        print("Destination pose:\n", actual_pose)

        self.pub_actual_pose()
        return
    
    def pub_actual_pose(self):
        actual_orientation = self.panda.get_orientation()

        self.panda_pose_pub.msg.position.x = self.panda.get_position()[0]
        self.panda_pose_pub.msg.position.y = self.panda.get_position()[1]
        self.panda_pose_pub.msg.position.z = self.panda.get_position()[2]
        self.panda_pose_pub.msg.orientation.x = actual_orientation[0]
        self.panda_pose_pub.msg.orientation.y = actual_orientation[1]
        self.panda_pose_pub.msg.orientation.z = actual_orientation[2]
        self.panda_pose_pub.msg.orientation.w = actual_orientation[3]
        self.panda_pose_pub.publish_wrapper()
        return
        
class PandaPosePub(Node):

    def __init__(self):
        super().__init__('panda_pose_publisher')
        self.msg:Pose = Pose()
        self.msg.orientation.x = 0.0
        self.msg.orientation.y = 0.0
        self.msg.orientation.z = 0.0
        self.msg.orientation.w = 1.0
        self.msg.position.x = 0.0
        self.msg.position.y = 0.0
        self.msg.position.z = 0.0
        self.publisher_ = self.create_publisher(Pose, 'panda_pose_topic', 10)

    def publish_wrapper(self):
        self.publisher_.publish(self.msg)

def main(args=None):
    rclpy.init(args=args)
    
    desk = panda_py.Desk("192.168.1.11" , "BRL" , "IITADVRBRL")
    # desk.unlock()
    # desk.activate_fci()
    panda = panda_py.Panda("192.168.1.11")

    panda_cmd_sub = PandaCmdSub(desk,panda)

    # executor = executors.SingleThreadedExecutor()
    # executor.add_node(panda_cmd_sub)
    # executor.add_node(panda_pose_pub)
    # executor.spin()

    rclpy.spin(panda_cmd_sub)

    panda_cmd_sub.destroy_node()

    # panda.move_to_start()
    desk.deactivate_fci()
    desk.lock()


if __name__ == '__main__':
    main()
