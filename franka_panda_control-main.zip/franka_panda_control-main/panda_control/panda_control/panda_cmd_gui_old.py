
import rclpy
from rclpy.node import Node
from panda_interfaces.msg import PandaCommand
from panda_interfaces.msg import PandaPose
from PyQt5 import QtWidgets, uic
import sys
import threading
import time

class PandaCmdPub(Node):

    def __init__(self):
        super().__init__('panda_cmd_publisher')
        self.msg:PandaCommand = PandaCommand()
        self.msg.run = True
        self.msg.unlocked = False
        self.msg.motion_type = 1
        self.msg.absolute_pose = True
        self.msg.rotation.data.append(0)
        self.msg.rotation.data.append(0)
        self.msg.rotation.data.append(0)
        self.msg.position.data.append(0.0)
        self.msg.position.data.append(0.0)
        self.msg.position.data.append(0.0)
        self.publisher_ = self.create_publisher(PandaCommand, 'panda_command_topic', 10)

    def publish_wrapper(self):
        self.publisher_.publish(self.msg)


# Subscriber class for PandaPose
class PandaPoseSub(Node):
	def __init__(self):
		super().__init__('panda_pose_subscriber')
		self.subscription = self.create_subscription(
			PandaPose,
			'panda_pose_topic',
			self.listener_callback,
			10
		)
		self.current_pose = PandaPose()
		self.current_pose.position.data.append(0.0)
		self.current_pose.position.data.append(0.0)
		self.current_pose.position.data.append(0.0)
		self.current_pose.rotation.data.append(0.0)
		self.current_pose.rotation.data.append(0.0)
		self.current_pose.rotation.data.append(0.0)
		self.received = False

	def listener_callback(self, msg:PandaPose):
		self.received = True
		self.current_pose.position.data[0] = msg.position.data[0]
		self.current_pose.position.data[1] = msg.position.data[1]
		self.current_pose.position.data[2] = msg.position.data[2]
		self.current_pose.rotation.data[0] = msg.rotation.data[0]
		self.current_pose.rotation.data[1] = msg.rotation.data[1]
		self.current_pose.rotation.data[2] = msg.rotation.data[2]
		# You can add logic here to process the received pose
		# print(f"Received PandaPose: position={msg.position.data}, rotation={msg.rotation.data}")


class PandaCmdGUI(QtWidgets.QMainWindow):
	def __init__(self):
		super().__init__()
		self.panda_cmd_pub = PandaCmdPub()
		self.panda_pose_sub = PandaPoseSub()
		uic.loadUi("/home/iit-rain/panda_ws/src/franka_panda_control/panda_control/gui/panda_cmd.ui", self)

		# Get widgets
		self.chk_unlock = self.findChild(QtWidgets.QCheckBox, "chk_unlock")
		self.chk_absolute_pose = self.findChild(QtWidgets.QCheckBox, "chk_absolute_pose")
		self.comboMotion = self.findChild(QtWidgets.QComboBox, "comboMotion")
		self.rot_x = self.findChild(QtWidgets.QDoubleSpinBox, "rot_x")
		self.rot_y = self.findChild(QtWidgets.QDoubleSpinBox, "rot_y")
		self.rot_z = self.findChild(QtWidgets.QDoubleSpinBox, "rot_z")
		self.pos_x = self.findChild(QtWidgets.QDoubleSpinBox, "pos_x")
		self.pos_y = self.findChild(QtWidgets.QDoubleSpinBox, "pos_y")
		self.pos_z = self.findChild(QtWidgets.QDoubleSpinBox, "pos_z")
		self.rot_x_feed = self.findChild(QtWidgets.QLabel, "rot_x_feed")
		self.rot_y_feed = self.findChild(QtWidgets.QLabel, "rot_y_feed")
		self.rot_z_feed = self.findChild(QtWidgets.QLabel, "rot_z_feed")
		self.pos_x_feed = self.findChild(QtWidgets.QLabel, "pos_x_feed")
		self.pos_y_feed = self.findChild(QtWidgets.QLabel, "pos_y_feed")
		self.pos_z_feed = self.findChild(QtWidgets.QLabel, "pos_z_feed")
		self.btn_send = self.findChild(QtWidgets.QPushButton, "btn_send")
		self.btn_home = self.findChild(QtWidgets.QPushButton, "btn_home")
		self.btn_close = self.findChild(QtWidgets.QPushButton, "btn_close")

		self.panda_cmd_pub.msg.unlocked = self.chk_unlock.isChecked()
		self.panda_cmd_pub.msg.absolute_pose = self.chk_absolute_pose.isChecked()
		self.panda_cmd_pub.msg.motion_type = self.comboMotion.currentIndex()+1
		self.panda_cmd_pub.msg.rotation.data[0] = self.rot_x.value()
		self.panda_cmd_pub.msg.rotation.data[1] = self.rot_y.value()
		self.panda_cmd_pub.msg.rotation.data[2] = self.rot_z.value()
		self.panda_cmd_pub.msg.position.data[0] = self.pos_x.value()
		self.panda_cmd_pub.msg.position.data[1] = self.pos_y.value()
		self.panda_cmd_pub.msg.position.data[2] = self.pos_z.value()

		# Connect callbacks for buttons
		self.btn_send.clicked.connect(self.on_send_clicked)
		self.btn_home.clicked.connect(self.on_home_clicked)
		self.btn_close.clicked.connect(self.on_close_clicked)

		# Connect callbacks for QLineEdit
		self.rot_x.editingFinished.connect(lambda: self.on_rot_spin_box_changed(self.rot_x,0))
		self.rot_y.editingFinished.connect(lambda: self.on_rot_spin_box_changed(self.rot_y,1))
		self.rot_z.editingFinished.connect(lambda: self.on_rot_spin_box_changed(self.rot_z,2))
		self.pos_x.editingFinished.connect(lambda: self.on_pos_spin_box_changed(self.pos_x,0))
		self.pos_y.editingFinished.connect(lambda: self.on_pos_spin_box_changed(self.pos_y,1))
		self.pos_z.editingFinished.connect(lambda: self.on_pos_spin_box_changed(self.pos_z,2))

		# Connect callbacks for QComboBox
		self.comboMotion.currentIndexChanged.connect(self.on_combobox_changed)

		# Connect callbacks for QCheckBox
		self.chk_unlock.stateChanged.connect(lambda state: self.on_checkbox_changed(self.chk_unlock, state))
		self.chk_absolute_pose.stateChanged.connect(lambda state: self.on_checkbox_changed(self.chk_absolute_pose, state))

		# spin the subscriber in a separate thread
		self.spin_thread = threading.Thread(target=rclpy.spin, args=(self.panda_pose_sub,), daemon=True)
		self.spin_thread.start()

		# Update the feedback labels periodically
		self.update_feedback_timer = threading.Thread(target=self.update_feedback_labels, daemon=True)
		self.update_feedback_timer.start()

	def update_feedback_labels(self):
		while rclpy.ok():
			if self.panda_pose_sub.received:
				self.rot_x_feed.setText(f"{self.panda_pose_sub.current_pose.rotation.data[0]:.5f}")
				self.rot_y_feed.setText(f"{self.panda_pose_sub.current_pose.rotation.data[1]:.5f}")
				self.rot_z_feed.setText(f"{self.panda_pose_sub.current_pose.rotation.data[2]:.5f}")
				self.pos_x_feed.setText(f"{self.panda_pose_sub.current_pose.position.data[0]:.5f}")
				self.pos_y_feed.setText(f"{self.panda_pose_sub.current_pose.position.data[1]:.5f}")
				self.pos_z_feed.setText(f"{self.panda_pose_sub.current_pose.position.data[2]:.5f}")

				if self.chk_absolute_pose.isChecked():
					self.on_checkbox_changed(self.chk_absolute_pose, None)
				self.panda_pose_sub.received = False
			time.sleep(0.1)  # Update every 100 ms

	def on_send_clicked(self):
		print("Send button clicked")
		self.panda_cmd_pub.publish_wrapper()
		# Add logic to handle sending command

	def on_home_clicked(self):
		print("Home button clicked")
		self.panda_cmd_pub.msg.motion_type = 0
		self.panda_cmd_pub.publish_wrapper()
		self.panda_cmd_pub.msg.motion_type = self.comboMotion.currentIndex()+1

	def on_close_clicked(self):
		print("Close button clicked")
		self.panda_cmd_pub.msg.run = False
		self.panda_cmd_pub.publish_wrapper()
		self.close()

	def on_rot_spin_box_changed(self, spinbox:QtWidgets.QDoubleSpinBox, i:int):
		self.panda_cmd_pub.msg.rotation.data[i] = spinbox.value()

	def on_pos_spin_box_changed(self, spinbox:QtWidgets.QDoubleSpinBox, i:int):
		self.panda_cmd_pub.msg.position.data[i] = spinbox.value()

	def on_combobox_changed(self, index):
		print(f"ComboBox '{self.comboMotion.objectName()}' changed: index={index}, text='{self.comboMotion.currentText()}'")
		self.panda_cmd_pub.msg.motion_type = index+1

	def on_checkbox_changed(self, checkbox, state):
		print(f"CheckBox '{checkbox.objectName()}' changed: checked={checkbox.isChecked()}")
		self.panda_cmd_pub.msg.unlocked = self.chk_unlock.isChecked()
		self.panda_cmd_pub.msg.absolute_pose = self.chk_absolute_pose.isChecked()
		if checkbox == self.chk_absolute_pose:
			if self.chk_absolute_pose.isChecked():
				self.pos_x.setValue(self.panda_pose_sub.current_pose.position.data[0])
				self.pos_y.setValue(self.panda_pose_sub.current_pose.position.data[1])
				self.pos_z.setValue(self.panda_pose_sub.current_pose.position.data[2])
				self.rot_x.setValue(self.panda_pose_sub.current_pose.rotation.data[0])
				self.rot_y.setValue(self.panda_pose_sub.current_pose.rotation.data[1])
				self.rot_z.setValue(self.panda_pose_sub.current_pose.rotation.data[2])
			else:
				self.pos_x.setValue(0.0)
				self.pos_y.setValue(0.0)
				self.pos_z.setValue(0.0)
				self.rot_x.setValue(0.0)
				self.rot_y.setValue(0.0)
				self.rot_z.setValue(0.0)
			self.panda_cmd_pub.msg.position.data[0] = self.pos_x.value()
			self.panda_cmd_pub.msg.position.data[1] = self.pos_y.value()
			self.panda_cmd_pub.msg.position.data[2] = self.pos_z.value()
			self.panda_cmd_pub.msg.rotation.data[0] = self.rot_x.value()
			self.panda_cmd_pub.msg.rotation.data[1] = self.rot_y.value()
			self.panda_cmd_pub.msg.rotation.data[2] = self.rot_z.value()

def main(args=None):
	rclpy.init(args=args)
	app = QtWidgets.QApplication(sys.argv)
	window = PandaCmdGUI()
	window.show()
	sys.exit(app.exec_())
	rclpy.shutdown()
	
if __name__ == "__main__":
	main()

